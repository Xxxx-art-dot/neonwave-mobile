import 'dart:ui';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../services/audio_handler.dart';
import '../services/audio_state.dart';
import 'player_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _searchController = TextEditingController();
  bool _isGridView = false;

  static const Color kCyberBg = Color(0xFF07060E);
  static const Color kCyberPanel = Color(0xFF0F0D1D);
  static const Color kCyberCard = Color(0xFF16132B);
  static const Color kCyberCyan = Color(0xFF00F5D4);
  static const Color kCyberMagenta = Color(0xFFFF2A85);
  static const Color kCyberViolet = Color(0xFF7B2CBF);

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  String _formatDuration(int totalSeconds) {
    if (totalSeconds <= 0) return '0:00';
    final mins = totalSeconds ~/ 60;
    final secs = totalSeconds % 60;
    return '$mins:${secs < 10 ? '0' : ''}$secs';
  }

  String _formatMegabytes(int bytes) {
    if (bytes <= 0) return '';
    final mb = bytes / (1024 * 1024);
    return '${mb.toStringAsFixed(1)} MB';
  }

  void _openIngestUrlDialog(BuildContext context) {
    final urlCtrl = TextEditingController();
    final titleCtrl = TextEditingController();
    final artistCtrl = TextEditingController();
    bool isSubmitting = false;

    showDialog<void>(
      context: context,
      builder: (dialogCtx) {
        return StatefulBuilder(
          builder: (ctx, setModalState) {
            return BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
              child: AlertDialog(
                backgroundColor: kCyberPanel.withOpacity(0.95),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(24),
                  side: BorderSide(color: kCyberCyan.withOpacity(0.35)),
                ),
                title: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: kCyberMagenta.withOpacity(0.18),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(Icons.cloud_download_rounded, color: kCyberMagenta, size: 22),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Ingest Web Audio Stream',
                            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: Colors.white),
                          ),
                          Text(
                            'yt-dlp 320kbps MP3 -> akram-hub.duckdns.org',
                            style: GoogleFonts.jetBrainsMono(fontSize: 10, color: Colors.white54),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                content: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      TextField(
                        controller: urlCtrl,
                        style: const TextStyle(color: Colors.white, fontSize: 13),
                        decoration: InputDecoration(
                          labelText: 'YouTube or SoundCloud URL *',
                          labelStyle: const TextStyle(color: kCyberCyan, fontSize: 12),
                          hintText: 'https://www.youtube.com/watch?v=...',
                          hintStyle: const TextStyle(color: Colors.white30, fontSize: 12),
                          filled: true,
                          fillColor: Colors.white.withOpacity(0.05),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: BorderSide(color: Colors.white.withOpacity(0.12)),
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: titleCtrl,
                        style: const TextStyle(color: Colors.white, fontSize: 13),
                        decoration: InputDecoration(
                          labelText: 'Optional Title Override',
                          labelStyle: const TextStyle(color: Colors.white60, fontSize: 12),
                          filled: true,
                          fillColor: Colors.white.withOpacity(0.04),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: artistCtrl,
                        style: const TextStyle(color: Colors.white, fontSize: 13),
                        decoration: InputDecoration(
                          labelText: 'Optional Artist Override',
                          labelStyle: const TextStyle(color: Colors.white60, fontSize: 12),
                          filled: true,
                          fillColor: Colors.white.withOpacity(0.04),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                actions: [
                  TextButton(
                    onPressed: isSubmitting ? null : () => Navigator.of(dialogCtx).pop(),
                    child: const Text('Cancel', style: TextStyle(color: Colors.white60)),
                  ),
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: kCyberCyan,
                      foregroundColor: Colors.black,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: isSubmitting
                        ? null
                        : () async {
                            final rawUrl = urlCtrl.text.trim();
                            if (rawUrl.isEmpty || !rawUrl.startsWith('http')) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('Enter a valid http:// or https:// URL')),
                              );
                              return;
                            }
                            setModalState(() => isSubmitting = true);
                            try {
                              final msg = await context.read<AudioState>().ingestWebUrl(
                                    url: rawUrl,
                                    customTitle: titleCtrl.text,
                                    customArtist: artistCtrl.text,
                                  );
                              if (context.mounted) {
                                Navigator.of(dialogCtx).pop();
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    backgroundColor: kCyberCard,
                                    content: Text(msg, style: const TextStyle(color: kCyberCyan)),
                                  ),
                                );
                              }
                            } catch (e) {
                              setModalState(() => isSubmitting = false);
                              if (context.mounted) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text('Ingestion failed: $e')),
                                );
                              }
                            }
                          },
                    icon: isSubmitting
                        ? const SizedBox(
                            width: 14,
                            height: 14,
                            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black),
                          )
                        : const Icon(Icons.bolt_rounded, size: 18),
                    label: Text(
                      isSubmitting ? 'Queueing...' : 'Download 320kbps',
                      style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final audioState = context.watch<AudioState>();
    final tracks = audioState.tracks;

    return Scaffold(
      backgroundColor: kCyberBg,
      body: Stack(
        children: [
          // Ambient Cyberpunk Glow Orbs
          Positioned(
            top: -90,
            left: -70,
            child: Container(
              width: 260,
              height: 260,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: kCyberViolet.withOpacity(0.22),
              ),
            ),
          ),
          Positioned(
            bottom: 120,
            right: -80,
            child: Container(
              width: 280,
              height: 280,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: kCyberCyan.withOpacity(0.12),
              ),
            ),
          ),
          BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 70, sigmaY: 70),
            child: const SizedBox.expand(),
          ),

          // Main Content Area
          SafeArea(
            child: Column(
              children: [
                // Top Glassmorphic App Bar
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                  child: Row(
                    children: [
                      Container(
                        width: 42,
                        height: 42,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(13),
                          gradient: const LinearGradient(
                            colors: [kCyberCyan, kCyberViolet, kCyberMagenta],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: kCyberCyan.withOpacity(0.28),
                              blurRadius: 14,
                            ),
                          ],
                        ),
                        child: const Center(
                          child: Icon(Icons.graphic_eq_rounded, color: Colors.black, size: 24),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'NEONWAVE',
                              style: TextStyle(
                                fontSize: 19,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1.4,
                                color: Colors.white,
                              ),
                            ),
                            Text(
                              'akram-hub.duckdns.org • EXOPLAYER DSP',
                              style: GoogleFonts.jetBrainsMono(
                                fontSize: 10,
                                color: kCyberCyan,
                              ),
                            ),
                          ],
                        ),
                      ),
                      // Ingest URL Button
                      IconButton(
                        tooltip: 'Ingest YouTube / SoundCloud URL',
                        onPressed: () => _openIngestUrlDialog(context),
                        style: IconButton.styleFrom(
                          backgroundColor: kCyberMagenta.withOpacity(0.16),
                          side: BorderSide(color: kCyberMagenta.withOpacity(0.45)),
                        ),
                        icon: const Icon(Icons.cloud_download_rounded, color: kCyberMagenta, size: 20),
                      ),
                      const SizedBox(width: 6),
                      // Favorites Filter Button
                      IconButton(
                        tooltip: 'Toggle Favorites Vault',
                        onPressed: audioState.toggleFavoritesFilter,
                        style: IconButton.styleFrom(
                          backgroundColor: audioState.favoritesOnly
                              ? kCyberMagenta.withOpacity(0.28)
                              : Colors.white.withOpacity(0.06),
                        ),
                        icon: Icon(
                          audioState.favoritesOnly ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                          color: audioState.favoritesOnly ? kCyberMagenta : Colors.white70,
                          size: 20,
                        ),
                      ),
                      const SizedBox(width: 6),
                      // Grid / List Toggle
                      IconButton(
                        tooltip: 'Switch Grid / List Layout',
                        onPressed: () => setState(() => _isGridView = !_isGridView),
                        style: IconButton.styleFrom(
                          backgroundColor: Colors.white.withOpacity(0.06),
                        ),
                        icon: Icon(
                          _isGridView ? Icons.view_list_rounded : Icons.grid_view_rounded,
                          color: kCyberCyan,
                          size: 20,
                        ),
                      ),
                    ],
                  ),
                ),

                // Instant Search Bar (`/api/tracks?limit=150`)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  child: TextField(
                    controller: _searchController,
                    onChanged: audioState.setSearchQuery,
                    onSubmitted: (val) => audioState.fetchTracks(query: val),
                    style: const TextStyle(color: Colors.white, fontSize: 14),
                    decoration: InputDecoration(
                      hintText: 'Search ${audioState.allTracks.length} tracks or artists...',
                      hintStyle: const TextStyle(color: Colors.white38, fontSize: 13),
                      prefixIcon: const Icon(Icons.search_rounded, color: kCyberCyan, size: 20),
                      suffixIcon: _searchController.text.isNotEmpty
                          ? IconButton(
                              icon: const Icon(Icons.clear_rounded, color: Colors.white54, size: 18),
                              onPressed: () {
                                _searchController.clear();
                                audioState.setSearchQuery('');
                                audioState.fetchTracks();
                              },
                            )
                          : IconButton(
                              tooltip: 'Refresh Server Library',
                              icon: const Icon(Icons.refresh_rounded, color: Colors.white54, size: 18),
                              onPressed: () => audioState.fetchTracks(query: _searchController.text),
                            ),
                      filled: true,
                      fillColor: kCyberPanel.withOpacity(0.85),
                      contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: BorderSide(color: Colors.white.withOpacity(0.1)),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: const BorderSide(color: kCyberCyan, width: 1.4),
                      ),
                    ),
                  ),
                ),

                // Active DSP Status Banner
                if (audioState.slowedReverb ||
                    audioState.nightcore ||
                    audioState.vocalIsolator ||
                    audioState.activeEqPreset != 'flat')
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: kCyberCyan.withOpacity(0.10),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: kCyberCyan.withOpacity(0.35)),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.tune_rounded, color: kCyberCyan, size: 16),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'HARDWARE DSP ACTIVE: '
                              '${audioState.slowedReverb ? 'SLOWED (${audioState.slowFactor.toStringAsFixed(2)}x) ' : ''}'
                              '${audioState.nightcore ? 'NIGHTCORE (1.25x) ' : ''}'
                              '${audioState.vocalIsolator ? 'VOCAL ISOLATOR ' : ''}'
                              '• EQ: ${audioState.activeEqPreset.toUpperCase()}',
                              style: GoogleFonts.jetBrainsMono(
                                fontSize: 10,
                                fontWeight: FontWeight.w600,
                                color: kCyberCyan,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          GestureDetector(
                            onTap: audioState.resetAllDsp,
                            child: Text(
                              'RESET',
                              style: GoogleFonts.jetBrainsMono(
                                fontSize: 10,
                                fontWeight: FontWeight.w800,
                                color: kCyberMagenta,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                // Main Track Catalog List / Grid
                Expanded(
                  child: RefreshIndicator(
                    color: kCyberCyan,
                    backgroundColor: kCyberPanel,
                    onRefresh: () => audioState.fetchTracks(query: _searchController.text),
                    child: _buildCatalogBody(context, audioState, tracks),
                  ),
                ),

                // Space for Floating Mini Player
                if (audioState.currentTrack != null) const SizedBox(height: 84),
              ],
            ),
          ),

          // Persistent Bottom Glassmorphic Mini-Player
          if (audioState.currentTrack != null)
            Positioned(
              left: 12,
              right: 12,
              bottom: 12,
              child: _buildMiniPlayer(context, audioState),
            ),
        ],
      ),
    );
  }

  Widget _buildCatalogBody(
    BuildContext context,
    AudioState audioState,
    List<TrackModel> tracks,
  ) {
    if (audioState.isLoadingCatalog && tracks.isEmpty) {
      return const Center(
        child: CircularProgressIndicator(color: kCyberCyan),
      );
    }

    if (audioState.catalogError != null && tracks.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.cloud_off_rounded, color: kCyberMagenta, size: 48),
              const SizedBox(height: 12),
              Text(
                audioState.catalogError!,
                textAlign: TextAlign.center,
                style: GoogleFonts.jetBrainsMono(fontSize: 12, color: Colors.white70),
              ),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: kCyberCyan,
                  foregroundColor: Colors.black,
                ),
                onPressed: () => audioState.fetchTracks(),
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('Retry Connection'),
              ),
            ],
          ),
        ),
      );
    }

    if (tracks.isEmpty) {
      return const Center(
        child: Text(
          'No matching tracks in library.',
          style: TextStyle(color: Colors.white54),
        ),
      );
    }

    if (_isGridView) {
      return GridView.builder(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 0.78,
        ),
        itemCount: tracks.length,
        itemBuilder: (ctx, idx) {
          final track = tracks[idx];
          final isCurrent = audioState.currentTrack?.id == track.id;
          return GestureDetector(
            onTap: () => audioState.playTrack(track),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: kCyberCard.withOpacity(0.85),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: isCurrent ? kCyberCyan : Colors.white.withOpacity(0.08),
                  width: isCurrent ? 1.5 : 1.0,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(14),
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          NeonCoverImage(coverUrl: track.coverUrl, title: track.title),
                          Positioned(
                            right: 8,
                            bottom: 8,
                            child: Container(
                              width: 34,
                              height: 34,
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                color: kCyberCyan,
                              ),
                              child: Icon(
                                isCurrent && audioState.isPlaying
                                    ? Icons.pause_rounded
                                    : Icons.play_arrow_rounded,
                                color: Colors.black,
                                size: 20,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    track.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 13,
                      color: isCurrent ? kCyberCyan : Colors.white,
                    ),
                  ),
                  Text(
                    track.artist,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 11, color: Colors.white60),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        _formatDuration(track.duration),
                        style: GoogleFonts.jetBrainsMono(fontSize: 10, color: Colors.white38),
                      ),
                      Text(
                        _formatMegabytes(track.fileSize),
                        style: GoogleFonts.jetBrainsMono(fontSize: 10, color: Colors.white38),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      itemCount: tracks.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (ctx, idx) {
        final track = tracks[idx];
        final isCurrent = audioState.currentTrack?.id == track.id;
        final isFav = audioState.isFavorite(track.id);

        return InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () => audioState.playTrack(track),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: isCurrent
                  ? kCyberCyan.withOpacity(0.12)
                  : kCyberPanel.withOpacity(0.75),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: isCurrent
                    ? kCyberCyan.withOpacity(0.55)
                    : Colors.white.withOpacity(0.07),
              ),
            ),
            child: Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(11),
                  child: SizedBox(
                    width: 50,
                    height: 50,
                    child: NeonCoverImage(coverUrl: track.coverUrl, title: track.title),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        track.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 14,
                          color: isCurrent ? kCyberCyan : Colors.white,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        track.artist,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 12, color: Colors.white60),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  _formatDuration(track.duration),
                  style: GoogleFonts.jetBrainsMono(fontSize: 11, color: Colors.white54),
                ),
                IconButton(
                  visualDensity: VisualDensity.compact,
                  onPressed: () => audioState.toggleFavorite(track.id),
                  icon: Icon(
                    isFav ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                    color: isFav ? kCyberMagenta : Colors.white38,
                    size: 19,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildMiniPlayer(BuildContext context, AudioState audioState) {
    final track = audioState.currentTrack!;
    final progress = audioState.duration.inMilliseconds > 0
        ? (audioState.position.inMilliseconds / audioState.duration.inMilliseconds).clamp(0.0, 1.0)
        : 0.0;

    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(
          MaterialPageRoute<void>(builder: (_) => const PlayerScreen()),
        );
      },
      child: ClipRRect(
        borderRadius: BorderRadius.circular(22),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
          child: Container(
            decoration: BoxDecoration(
              color: const Color(0xFF0B0919).withOpacity(0.92),
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: kCyberCyan.withOpacity(0.38)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.65),
                  blurRadius: 24,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                LinearProgressIndicator(
                  value: progress,
                  minHeight: 2.5,
                  backgroundColor: Colors.white12,
                  valueColor: const AlwaysStoppedAnimation<Color>(kCyberCyan),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 8, 8, 8),
                  child: Row(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(11),
                        child: SizedBox(
                          width: 44,
                          height: 44,
                          child: NeonCoverImage(coverUrl: track.coverUrl, title: track.title),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              track.title,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 13,
                                color: Colors.white,
                              ),
                            ),
                            Text(
                              track.artist,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontSize: 11, color: kCyberCyan),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        onPressed: audioState.playPrevious,
                        icon: const Icon(Icons.skip_previous_rounded, color: Colors.white),
                      ),
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(13),
                          gradient: const LinearGradient(
                            colors: [kCyberCyan, Color(0xFF00BBF9)],
                          ),
                        ),
                        child: IconButton(
                          padding: EdgeInsets.zero,
                          onPressed: audioState.togglePlayPause,
                          icon: Icon(
                            audioState.isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                            color: Colors.black,
                            size: 24,
                          ),
                        ),
                      ),
                      IconButton(
                        onPressed: audioState.playNext,
                        icon: const Icon(Icons.skip_next_rounded, color: Colors.white),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Smart Artwork Loader supporting both JPEG/PNG ID3 covers and FastAPI SVG fallbacks
class NeonCoverImage extends StatelessWidget {
  final String coverUrl;
  final String title;

  const NeonCoverImage({
    super.key,
    required this.coverUrl,
    required this.title,
  });

  @override
  Widget build(BuildContext context) {
    return CachedNetworkImage(
      imageUrl: coverUrl,
      fit: BoxFit.cover,
      placeholder: (_, __) => _buildFallbackBox(),
      errorWidget: (_, __, ___) {
        // Attempt SVG render if server returned image/svg+xml fallback
        return SvgPicture.network(
          coverUrl,
          fit: BoxFit.cover,
          placeholderBuilder: (_) => _buildFallbackBox(),
        );
      },
    );
  }

  Widget _buildFallbackBox() {
    final initials = title.trim().isNotEmpty
        ? title.trim().substring(0, title.trim().length >= 2 ? 2 : 1).toUpperCase()
        : 'NW';
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF141029), Color(0xFF2B124C)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Center(
        child: Text(
          initials,
          style: GoogleFonts.jetBrainsMono(
            fontWeight: FontWeight.w800,
            fontSize: 16,
            color: const Color(0xFF00F5D4),
          ),
        ),
      ),
    );
  }
}

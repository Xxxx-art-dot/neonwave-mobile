import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:just_audio/just_audio.dart';
import 'package:provider/provider.dart';
import '../services/audio_handler.dart';
import '../services/audio_state.dart';
import 'home_screen.dart';

class PlayerScreen extends StatefulWidget {
  const PlayerScreen({super.key});

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _vinylController;
  double? _dragSeekSeconds;

  static const Color kCyberBg = Color(0xFF07060E);
  static const Color kCyberPanel = Color(0xFF0F0D1D);
  static const Color kCyberCard = Color(0xFF16132B);
  static const Color kCyberCyan = Color(0xFF00F5D4);
  static const Color kCyberMagenta = Color(0xFFFF2A85);
  static const Color kCyberViolet = Color(0xFF7B2CBF);

  @override
  void initState() {
    super.initState();
    _vinylController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 18),
    )..repeat();
  }

  @override
  void dispose() {
    _vinylController.dispose();
    super.dispose();
  }

  String _formatDuration(Duration d) {
    final total = d.inSeconds;
    if (total <= 0) return '0:00';
    final mins = total ~/ 60;
    final secs = total % 60;
    return '$mins:${secs < 10 ? '0' : ''}$secs';
  }

  // =========================================================================
  // 1. 10-BAND PARAMETRIC EQ & DSP STUDIO BOTTOM SHEET
  // =========================================================================
  void _openFullEqStudioModal(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetCtx) {
        return Consumer<AudioState>(
          builder: (ctx, audioState, _) {
            final gains = audioState.eqGains;
            final freqs = NeonDspPresets.frequencies;

            return BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
              child: Container(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
                decoration: BoxDecoration(
                  color: kCyberPanel.withOpacity(0.95),
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
                  border: Border.all(color: kCyberCyan.withOpacity(0.35)),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              '🎛️ Hardware DSP & 10-Band EQ Studio',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w800,
                                color: Colors.white,
                              ),
                            ),
                            Text(
                              'Android Native Equalizer + Sonic Pitch Processor',
                              style: GoogleFonts.jetBrainsMono(
                                fontSize: 10,
                                color: kCyberCyan,
                              ),
                            ),
                          ],
                        ),
                        TextButton(
                          onPressed: audioState.resetAllDsp,
                          child: Text(
                            'RESET ALL',
                            style: GoogleFonts.jetBrainsMono(
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                              color: kCyberMagenta,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),

                    // Slowed + Reverb Factor Slider
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.04),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: Colors.white10),
                      ),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                'Slowed + Reverb Factor (Pitch & Speed)',
                                style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
                              ),
                              Text(
                                '${audioState.slowFactor.toStringAsFixed(2)}x',
                                style: GoogleFonts.jetBrainsMono(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  color: kCyberMagenta,
                                ),
                              ),
                            ],
                          ),
                          Slider(
                            value: audioState.slowFactor,
                            min: 0.75,
                            max: 0.95,
                            divisions: 20,
                            activeColor: kCyberMagenta,
                            onChanged: (val) => audioState.updateSlowFactor(val),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 14),

                    // 10-Band Vertical Sliders
                    SizedBox(
                      height: 190,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: List<Widget>.generate(freqs.length, (idx) {
                          final hz = freqs[idx];
                          final label = hz >= 1000
                              ? '${(hz / 1000).toStringAsFixed(0)}k'
                              : hz.toStringAsFixed(0);
                          final db = gains[idx];
                          return Expanded(
                            child: Column(
                              children: [
                                Text(
                                  '${db >= 0 ? '+' : ''}${db.toStringAsFixed(0)}',
                                  style: GoogleFonts.jetBrainsMono(
                                    fontSize: 9,
                                    color: kCyberCyan,
                                  ),
                                ),
                                Expanded(
                                  child: RotatedBox(
                                    quarterTurns: 3,
                                    child: SliderTheme(
                                      data: SliderTheme.of(context).copyWith(
                                        trackHeight: 3,
                                        thumbShape: const RoundSliderThumbShape(
                                          enabledThumbRadius: 6,
                                        ),
                                      ),
                                      child: Slider(
                                        value: db,
                                        min: -12.0,
                                        max: 12.0,
                                        activeColor: kCyberCyan,
                                        inactiveColor: Colors.white12,
                                        onChanged: (val) =>
                                            audioState.setEqBandGain(idx, val),
                                      ),
                                    ),
                                  ),
                                ),
                                Text(
                                  label,
                                  style: GoogleFonts.jetBrainsMono(
                                    fontSize: 9,
                                    color: Colors.white54,
                                  ),
                                ),
                              ],
                            ),
                          );
                        }),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  // =========================================================================
  // 2. SYNCED LYRICS DRAWER (`/api/track/{id}/lyrics` + AUTO-SCROLL)
  // =========================================================================
  void _openSyncedLyricsDrawer(BuildContext context) {
    final ScrollController scrollController = ScrollController();
    int lastScrolledIndex = -1;

    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetCtx) {
        return Consumer<AudioState>(
          builder: (ctx, audioState, _) {
            final lines = audioState.lyrics;
            final activeIdx = audioState.activeLyricIndex;

            if (activeIdx >= 0 &&
                activeIdx != lastScrolledIndex &&
                scrollController.hasClients) {
              lastScrolledIndex = activeIdx;
              WidgetsBinding.instance.addPostFrameCallback((_) {
                if (!scrollController.hasClients) return;
                final targetOffset = (activeIdx * 56.0) - 140.0;
                scrollController.animateTo(
                  targetOffset.clamp(
                    0.0,
                    scrollController.position.maxScrollExtent,
                  ),
                  duration: const Duration(milliseconds: 320),
                  curve: Curves.easeOutCubic,
                );
              });
            }

            return BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 22, sigmaY: 22),
              child: Container(
                height: MediaQuery.of(context).size.height * 0.72,
                padding: const EdgeInsets.fromLTRB(20, 18, 20, 20),
                decoration: BoxDecoration(
                  color: kCyberPanel.withOpacity(0.95),
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
                  border: Border.all(color: kCyberCyan.withOpacity(0.35)),
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            const Text(
                              '🎤 Synced Lyrics',
                              style: TextStyle(
                                fontSize: 17,
                                fontWeight: FontWeight.w800,
                                color: Colors.white,
                              ),
                            ),
                            const SizedBox(width: 10),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 3,
                              ),
                              decoration: BoxDecoration(
                                color: kCyberCyan.withOpacity(0.15),
                                borderRadius: BorderRadius.circular(99),
                              ),
                              child: Text(
                                audioState.lyricsSource,
                                style: GoogleFonts.jetBrainsMono(
                                  fontSize: 10,
                                  fontWeight: FontWeight.w700,
                                  color: kCyberCyan,
                                ),
                              ),
                            ),
                          ],
                        ),
                        IconButton(
                          onPressed: () => Navigator.of(sheetCtx).pop(),
                          icon: const Icon(Icons.close_rounded, color: Colors.white70),
                        ),
                      ],
                    ),
                    const Divider(color: Colors.white12),
                    Expanded(
                      child: audioState.isLoadingLyrics
                          ? const Center(
                              child: CircularProgressIndicator(color: kCyberCyan),
                            )
                          : ListView.builder(
                              controller: scrollController,
                              itemCount: lines.length,
                              itemBuilder: (ctx, idx) {
                                final line = lines[idx];
                                final isActive = idx == activeIdx;
                                return InkWell(
                                  borderRadius: BorderRadius.circular(14),
                                  onTap: () => audioState.seek(
                                    Duration(
                                      milliseconds: (line.timeSeconds * 1000).round(),
                                    ),
                                  ),
                                  child: AnimatedContainer(
                                    duration: const Duration(milliseconds: 220),
                                    padding: const EdgeInsets.symmetric(
                                      vertical: 12,
                                      horizontal: 14,
                                    ),
                                    decoration: BoxDecoration(
                                      color: isActive
                                          ? kCyberCyan.withOpacity(0.12)
                                          : Colors.transparent,
                                      borderRadius: BorderRadius.circular(14),
                                    ),
                                    child: Text(
                                      line.text,
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        fontSize: isActive ? 17 : 14,
                                        fontWeight: isActive
                                            ? FontWeight.w800
                                            : FontWeight.w500,
                                        color: isActive ? kCyberCyan : Colors.white54,
                                        shadows: isActive
                                            ? [
                                                Shadow(
                                                  color: kCyberCyan.withOpacity(0.6),
                                                  blurRadius: 14,
                                                ),
                                              ]
                                            : null,
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final audioState = context.watch<AudioState>();
    final track = audioState.currentTrack;

    if (track == null) {
      return const Scaffold(
        backgroundColor: kCyberBg,
        body: Center(child: Text('No track selected')),
      );
    }

    final totalSeconds = math.max(
      1.0,
      audioState.duration.inMilliseconds / 1000.0,
    );
    final currentSeconds = (_dragSeekSeconds ??
            (audioState.position.inMilliseconds / 1000.0))
        .clamp(0.0, totalSeconds);

    return Scaffold(
      backgroundColor: kCyberBg,
      body: Stack(
        children: [
          // Blurred Cover Background
          Positioned.fill(
            child: Opacity(
              opacity: 0.22,
              child: NeonCoverImage(coverUrl: track.coverUrl, title: track.title),
            ),
          ),
          Positioned.fill(
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 55, sigmaY: 55),
              child: Container(color: kCyberBg.withOpacity(0.75)),
            ),
          ),

          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 10),
              child: Column(
                children: [
                  // Top Bar
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      IconButton(
                        onPressed: () => Navigator.of(context).pop(),
                        icon: const Icon(
                          Icons.keyboard_arrow_down_rounded,
                          color: Colors.white,
                          size: 30,
                        ),
                      ),
                      Column(
                        children: [
                          Text(
                            'NOW STREAMING // HTTP 206',
                            style: GoogleFonts.jetBrainsMono(
                              fontSize: 10,
                              letterSpacing: 1.5,
                              color: kCyberCyan,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            'ID #${track.id} • EXOPLAYER ENGINE',
                            style: GoogleFonts.jetBrainsMono(
                              fontSize: 10,
                              color: Colors.white54,
                            ),
                          ),
                        ],
                      ),
                      IconButton(
                        tooltip: 'Open 10-Band EQ Studio',
                        onPressed: () => _openFullEqStudioModal(context),
                        icon: const Icon(Icons.equalizer_rounded, color: kCyberCyan),
                      ),
                    ],
                  ),

                  const Spacer(),

                  // Rotating High-Res Cover Art Disc
                  AnimatedBuilder(
                    animation: _vinylController,
                    builder: (context, child) {
                      final angle = audioState.isPlaying
                          ? _vinylController.value * 2 * math.pi
                          : 0.0;
                      return Transform.rotate(angle: angle, child: child);
                    },
                    child: Container(
                      width: 250,
                      height: 250,
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: const LinearGradient(
                          colors: [kCyberCyan, kCyberViolet, kCyberMagenta],
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: kCyberCyan.withOpacity(0.28),
                            blurRadius: 36,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: ClipOval(
                        child: Stack(
                          fit: StackFit.expand,
                          children: [
                            NeonCoverImage(
                              coverUrl: track.coverUrl,
                              title: track.title,
                            ),
                            Center(
                              child: Container(
                                width: 38,
                                height: 38,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: kCyberBg,
                                  border: Border.all(color: kCyberCyan, width: 2),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),

                  const Spacer(),

                  // Track Title, Artist & Favorite Toggle
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              track.title,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.w900,
                                color: Colors.white,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              track.artist,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w600,
                                color: kCyberCyan,
                              ),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        onPressed: () => audioState.toggleFavorite(track.id),
                        icon: Icon(
                          audioState.isFavorite(track.id)
                              ? Icons.favorite_rounded
                              : Icons.favorite_border_rounded,
                          color: audioState.isFavorite(track.id)
                              ? kCyberMagenta
                              : Colors.white60,
                          size: 28,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 14),

                  // DSP Quick Toggles Strip (Slowed+Reverb, Nightcore, Vocal Isolator, 10-Band EQ Presets)
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        _buildDspChip(
                          label: 'Slowed + Reverb (0.85x)',
                          active: audioState.slowedReverb,
                          activeColor: kCyberMagenta,
                          onTap: audioState.toggleSlowedReverb,
                        ),
                        const SizedBox(width: 8),
                        _buildDspChip(
                          label: 'Nightcore (1.25x)',
                          active: audioState.nightcore,
                          activeColor: kCyberCyan,
                          onTap: audioState.toggleNightcore,
                        ),
                        const SizedBox(width: 8),
                        _buildDspChip(
                          label: 'Vocal Isolator',
                          active: audioState.vocalIsolator,
                          activeColor: kCyberMagenta,
                          onTap: audioState.toggleVocalIsolator,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _buildPresetPill(audioState, 'flat', 'EQ: Flat'),
                      const SizedBox(width: 8),
                      _buildPresetPill(audioState, 'cyberbass', 'CyberBass Boost'),
                      const SizedBox(width: 8),
                      _buildPresetPill(audioState, 'vocal', 'Vocal Clarity'),
                    ],
                  ),

                  const SizedBox(height: 14),

                  // Precision Draggable Seek Bar
                  SliderTheme(
                    data: SliderTheme.of(context).copyWith(
                      trackHeight: 5,
                      thumbShape:
                          const RoundSliderThumbShape(enabledThumbRadius: 7),
                    ),
                    child: Slider(
                      value: currentSeconds,
                      min: 0.0,
                      max: totalSeconds,
                      activeColor: kCyberCyan,
                      inactiveColor: Colors.white12,
                      onChanged: (val) => setState(() => _dragSeekSeconds = val),
                      onChangeEnd: (val) {
                        audioState.seek(
                          Duration(milliseconds: (val * 1000).round()),
                        );
                        setState(() => _dragSeekSeconds = null);
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          _formatDuration(
                            Duration(milliseconds: (currentSeconds * 1000).round()),
                          ),
                          style: GoogleFonts.jetBrainsMono(
                            fontSize: 11,
                            color: Colors.white60,
                          ),
                        ),
                        Text(
                          _formatDuration(audioState.duration),
                          style: GoogleFonts.jetBrainsMono(
                            fontSize: 11,
                            color: Colors.white60,
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 12),

                  // Primary Transport Controls
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      IconButton(
                        onPressed: audioState.toggleShuffle,
                        icon: Icon(
                          Icons.shuffle_rounded,
                          color: audioState.shuffleEnabled
                              ? kCyberCyan
                              : Colors.white54,
                        ),
                      ),
                      IconButton(
                        iconSize: 36,
                        onPressed: audioState.playPrevious,
                        icon: const Icon(
                          Icons.skip_previous_rounded,
                          color: Colors.white,
                        ),
                      ),
                      GestureDetector(
                        onTap: audioState.togglePlayPause,
                        child: Container(
                          width: 68,
                          height: 68,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(22),
                            gradient: const LinearGradient(
                              colors: [kCyberCyan, Color(0xFF00BBF9)],
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: kCyberCyan.withOpacity(0.38),
                                blurRadius: 20,
                                offset: const Offset(0, 6),
                              ),
                            ],
                          ),
                          child: Icon(
                            audioState.isPlaying
                                ? Icons.pause_rounded
                                : Icons.play_arrow_rounded,
                            color: Colors.black,
                            size: 38,
                          ),
                        ),
                      ),
                      IconButton(
                        iconSize: 36,
                        onPressed: audioState.playNext,
                        icon: const Icon(
                          Icons.skip_next_rounded,
                          color: Colors.white,
                        ),
                      ),
                      IconButton(
                        onPressed: audioState.cycleLoopMode,
                        icon: Icon(
                          audioState.loopMode == LoopMode.one
                              ? Icons.repeat_one_rounded
                              : Icons.repeat_rounded,
                          color: audioState.loopMode != LoopMode.off
                              ? kCyberCyan
                              : Colors.white54,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 14),

                  // Bottom Studio Drawer Triggers (Synced Lyrics & 10-Band Customizer)
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          style: OutlinedButton.styleFrom(
                            foregroundColor: kCyberCyan,
                            side: BorderSide(color: kCyberCyan.withOpacity(0.4)),
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14),
                            ),
                          ),
                          onPressed: () => _openSyncedLyricsDrawer(context),
                          icon: const Icon(Icons.lyrics_rounded, size: 18),
                          label: const Text(
                            'Synced Lyrics (LRCLIB)',
                            style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: OutlinedButton.icon(
                          style: OutlinedButton.styleFrom(
                            foregroundColor: Colors.white,
                            side: const BorderSide(color: Colors.white24),
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14),
                            ),
                          ),
                          onPressed: () => _openFullEqStudioModal(context),
                          icon: const Icon(Icons.tune_rounded, size: 18),
                          label: const Text(
                            '10-Band Sliders',
                            style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDspChip({
    required String label,
    required bool active,
    required Color activeColor,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(
          color: active ? activeColor.withOpacity(0.22) : Colors.white.withOpacity(0.05),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: active ? activeColor : Colors.white.withOpacity(0.12),
          ),
        ),
        child: Text(
          label,
          style: GoogleFonts.jetBrainsMono(
            fontSize: 11,
            fontWeight: FontWeight.w700,
            color: active ? activeColor : Colors.white70,
          ),
        ),
      ),
    );
  }

  Widget _buildPresetPill(AudioState state, String key, String label) {
    final isSelected = state.activeEqPreset == key;
    return GestureDetector(
      onTap: () => state.selectEqPreset(key),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: isSelected
              ? kCyberCyan.withOpacity(0.2)
              : Colors.white.withOpacity(0.04),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: isSelected ? kCyberCyan : Colors.white12,
          ),
        ),
        child: Text(
          label,
          style: GoogleFonts.jetBrainsMono(
            fontSize: 10,
            fontWeight: isSelected ? FontWeight.w800 : FontWeight.w500,
            color: isSelected ? kCyberCyan : Colors.white60,
          ),
        ),
      ),
    );
  }
}

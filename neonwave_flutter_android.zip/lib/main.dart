import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import 'screens/home_screen.dart';
import 'services/audio_handler.dart';
import 'services/audio_state.dart';

Future<void> main() async {
  // 1. Ensure Flutter engine & platform channels are bound first
  WidgetsFlutterBinding.ensureInitialized();

  // 2. Request Android 13/14+ (API 33+) runtime notification permission immediately
  try {
    await Permission.notification.request();
  } catch (_) {}

  // 3. Initialize AudioSession + AudioService notification channel ('org.neonwave.audio.playback.v4')
  final NeonwaveAudioHandler audioHandler = await initNeonwaveAudioService();

  // Configure edge-to-edge Cyberpunk status/navigation bars
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Color(0xFF07060E),
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );

  // 4. Launch app with singleton AudioHandler & AudioState injected into MultiProvider
  runApp(
    MultiProvider(
      providers: [
        Provider<NeonwaveAudioHandler>.value(value: audioHandler),
        ChangeNotifierProvider<AudioState>(
          create: (_) => AudioState(audioHandler: audioHandler),
        ),
      ],
      child: const NeonwaveApp(),
    ),
  );
}

class NeonwaveApp extends StatelessWidget {
  const NeonwaveApp({super.key});

  static const Color kCyberBg = Color(0xFF07060E);
  static const Color kCyberPanel = Color(0xFF0F0D1D);
  static const Color kCyberCard = Color(0xFF16132B);
  static const Color kCyberCyan = Color(0xFF00F5D4);
  static const Color kCyberMagenta = Color(0xFFFF2A85);
  static const Color kCyberViolet = Color(0xFF7B2CBF);

  @override
  Widget build(BuildContext context) {
    final baseTextTheme = GoogleFonts.interTextTheme(ThemeData.dark().textTheme);

    return MaterialApp(
      title: 'NEONWAVE',
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.dark,
      darkTheme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: kCyberBg,
        primaryColor: kCyberCyan,
        colorScheme: const ColorScheme.dark(
          primary: kCyberCyan,
          secondary: kCyberMagenta,
          tertiary: kCyberViolet,
          surface: kCyberPanel,
        ),
        textTheme: baseTextTheme.apply(
          bodyColor: const Color(0xFFF8FAFC),
          displayColor: Colors.white,
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

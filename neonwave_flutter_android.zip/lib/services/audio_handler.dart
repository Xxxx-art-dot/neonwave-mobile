import 'dart:async';
import 'dart:io';
import 'package:audio_service/audio_service.dart';
import 'package:audio_session/audio_session.dart';
import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';

/// Canonical FastAPI Production Server URL
const String kBaseServerUrl = 'https://akram-hub.duckdns.org';

/// Immutable representation of a NEONWAVE Track from `/api/tracks`
class TrackModel {
  final int id;
  final String title;
  final String artist;
  final int duration;
  final int fileSize;
  final String streamUrl;
  final String coverUrl;
  final String addedAt;

  const TrackModel({
    required this.id,
    required this.title,
    required this.artist,
    required this.duration,
    required this.fileSize,
    required this.streamUrl,
    required this.coverUrl,
    required this.addedAt,
  });

  factory TrackModel.fromJson(Map<String, dynamic> json) {
    final int trackId = json['id'] is int
        ? json['id'] as int
        : int.tryParse(json['id'].toString()) ?? 0;

    String resolveUrl(String? raw, String fallbackPath) {
      final path = (raw != null && raw.trim().isNotEmpty) ? raw.trim() : fallbackPath;
      if (path.startsWith('http://') || path.startsWith('https://')) {
        return path;
      }
      return '$kBaseServerUrl${path.startsWith('/') ? '' : '/'}$path';
    }

    return TrackModel(
      id: trackId,
      title: (json['title'] as String?)?.trim().isNotEmpty == true
          ? (json['title'] as String).trim()
          : 'Untitled Track',
      artist: (json['artist'] as String?)?.trim().isNotEmpty == true
          ? (json['artist'] as String).trim()
          : 'Unknown Artist',
      duration: json['duration'] is int
          ? json['duration'] as int
          : int.tryParse(json['duration']?.toString() ?? '0') ?? 0,
      fileSize: json['file_size'] is int
          ? json['file_size'] as int
          : int.tryParse(json['file_size']?.toString() ?? '0') ?? 0,
      streamUrl: resolveUrl(json['stream_url'] as String?, '/api/stream/$trackId'),
      coverUrl: resolveUrl(json['cover_url'] as String?, '/api/track/$trackId/cover'),
      addedAt: (json['added_at'] as String?) ?? '',
    );
  }

  MediaItem toMediaItem() {
    return MediaItem(
      id: id.toString(),
      album: 'NEONWAVE // Cyber-Sonic Vault',
      title: title,
      artist: artist,
      duration: Duration(seconds: duration),
      artUri: Uri.parse(coverUrl),
      extras: <String, dynamic>{
        'track_id': id,
        'stream_url': streamUrl,
        'cover_url': coverUrl,
        'file_size': fileSize,
      },
    );
  }
}

/// 10-Band Reference Frequencies (32Hz -> 16kHz) & Presets in dB (-12.0 to +12.0)
class NeonDspPresets {
  static const List<double> frequencies = <double>[
    32, 64, 125, 250, 500, 1000, 2000, 4000, 8000, 16000
  ];

  static const Map<String, List<double>> presets = <String, List<double>>{
    'flat': <double>[0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    'cyberbass': <double>[8.5, 7.0, 4.5, 1.5, -1.0, -0.5, 1.5, 3.0, 4.5, 5.0],
    'vocal': <double>[-3.0, -2.0, -1.0, 2.0, 4.5, 6.0, 5.5, 3.0, 1.5, 0.5],
  };
}

/// Initialize the Foreground AudioService + Hardware ExoPlayer Handler
Future<NeonwaveAudioHandler> initNeonwaveAudioService() async {
  return await AudioService.init(
    builder: () => NeonwaveAudioHandler(),
    config: const AudioServiceConfig(
      androidNotificationChannelId: 'org.neonwave.audio.channel',
      androidNotificationChannelName: 'NEONWAVE Cyber-Sonic Playback',
      androidNotificationChannelDescription:
          'Hardware-accelerated audio streaming & DSP controls',
      androidNotificationOngoing: true,
      androidStopForegroundOnPause: true,
      androidNotificationIcon: 'mipmap/ic_launcher',
    ),
  );
}

/// Hardware-backed AudioHandler bridging `just_audio` (ExoPlayer) + `audio_service`
class NeonwaveAudioHandler extends BaseAudioHandler with QueueHandler, SeekHandler {
  late final AudioPlayer _player;
  final AndroidEqualizer _androidEqualizer = AndroidEqualizer();
  final AndroidLoudnessEnhancer _loudnessEnhancer = AndroidLoudnessEnhancer();

  final ConcatenatingAudioSource _playlist =
      ConcatenatingAudioSource(children: <AudioSource>[]);

  List<TrackModel> _catalogQueue = <TrackModel>[];

  // DSP State
  bool _slowedReverbEnabled = false;
  double _slowFactor = 0.85;
  bool _nightcoreEnabled = false;
  bool _vocalIsolatorEnabled = false;
  String _activeEqPreset = 'flat';
  List<double> _virtual10BandGains = List<double>.filled(10, 0.0);

  AudioPlayer get player => _player;
  List<TrackModel> get catalogQueue => List<TrackModel>.unmodifiable(_catalogQueue);
  bool get slowedReverbEnabled => _slowedReverbEnabled;
  double get slowFactor => _slowFactor;
  bool get nightcoreEnabled => _nightcoreEnabled;
  bool get vocalIsolatorEnabled => _vocalIsolatorEnabled;
  String get activeEqPreset => _activeEqPreset;
  List<double> get virtual10BandGains => List<double>.unmodifiable(_virtual10BandGains);

  NeonwaveAudioHandler() {
    _player = AudioPlayer(
      audioPipeline: AudioPipeline(
        androidAudioEffects: <AndroidAudioEffect>[
          _androidEqualizer,
          _loudnessEnhancer,
        ],
      ),
    );
    _initAudioPipeline();
  }

  Future<void> _initAudioPipeline() async {
    final session = await AudioSession.instance;
    await session.configure(const AudioSessionConfiguration.music());

    if (!kIsWeb && Platform.isAndroid) {
      await _androidEqualizer.setEnabled(true);
      await _loudnessEnhancer.setEnabled(true);
      await _loudnessEnhancer.setTargetGain(0.0);
    }

    // Pipe ExoPlayer playback events into Android MediaSession notification state
    _player.playbackEventStream.map(_transformEvent).pipe(playbackState);

    // Sync active index changes with lock-screen MediaItem metadata
    _player.currentIndexStream.listen((int? index) {
      if (index != null && index >= 0 && index < _catalogQueue.length) {
        final track = _catalogQueue[index];
        final duration = _player.duration ?? Duration(seconds: track.duration);
        mediaItem.add(track.toMediaItem().copyWith(duration: duration));
      }
    });

    // Update lock-screen duration once HTTP 206 stream headers resolve
    _player.durationStream.listen((Duration? d) {
      final current = mediaItem.value;
      if (current != null && d != null && d.inSeconds > 0) {
        mediaItem.add(current.copyWith(duration: d));
      }
    });
  }

  /// Load track list into ConcatenatingAudioSource and start streaming at [initialIndex]
  Future<void> loadPlaylist(
    List<TrackModel> tracks, {
    int initialIndex = 0,
    bool autoPlay = true,
  }) async {
    _catalogQueue = List<TrackModel>.from(tracks);
    final mediaItems = _catalogQueue.map((t) => t.toMediaItem()).toList();
    queue.add(mediaItems);

    final sources = _catalogQueue.map((track) {
      return AudioSource.uri(
        Uri.parse(track.streamUrl),
        tag: track.toMediaItem(),
      );
    }).toList();

    await _playlist.clear();
    await _playlist.addAll(sources);

    final safeIndex = initialIndex.clamp(0, _catalogQueue.isEmpty ? 0 : _catalogQueue.length - 1);
    if (_catalogQueue.isNotEmpty) {
      mediaItem.add(_catalogQueue[safeIndex].toMediaItem());
    }

    await _player.setAudioSource(
      _playlist,
      initialIndex: _catalogQueue.isEmpty ? null : safeIndex,
      initialPosition: Duration.zero,
    );

    await _applyDspEngineSettings();
    if (autoPlay && _catalogQueue.isNotEmpty) {
      await _player.play();
    }
  }

  /// Play a specific track immediately (appending to queue if needed)
  Future<void> playTrack(TrackModel track, {List<TrackModel>? fullCatalog}) async {
    if (_catalogQueue.isEmpty && fullCatalog != null && fullCatalog.isNotEmpty) {
      final idx = fullCatalog.indexWhere((t) => t.id == track.id);
      await loadPlaylist(
        fullCatalog,
        initialIndex: idx >= 0 ? idx : 0,
        autoPlay: true,
      );
      return;
    }

    final existingIndex = _catalogQueue.indexWhere((t) => t.id == track.id);
    if (existingIndex >= 0) {
      await skipToQueueItem(existingIndex);
      await _player.play();
    } else {
      _catalogQueue.add(track);
      queue.add(_catalogQueue.map((t) => t.toMediaItem()).toList());
      await _playlist.add(
        AudioSource.uri(Uri.parse(track.streamUrl), tag: track.toMediaItem()),
      );
      await skipToQueueItem(_catalogQueue.length - 1);
      await _player.play();
    }
  }

  // =========================================================================
  // HARDWARE DSP SUITE (SLOWED+REVERB, NIGHTCORE, VOCAL ISOLATOR, 10-BAND EQ)
  // =========================================================================
  Future<void> setSlowedReverb(bool enabled, {double? customFactor}) async {
    _slowedReverbEnabled = enabled;
    if (customFactor != null) {
      _slowFactor = customFactor.clamp(0.75, 0.95);
    }
    if (enabled) {
      _nightcoreEnabled = false;
    }
    await _applyDspEngineSettings();
  }

  Future<void> setNightcore(bool enabled) async {
    _nightcoreEnabled = enabled;
    if (enabled) {
      _slowedReverbEnabled = false;
    }
    await _applyDspEngineSettings();
  }

  Future<void> setVocalIsolator(bool enabled) async {
    _vocalIsolatorEnabled = enabled;
    await _applyDspEngineSettings();
  }

  Future<void> applyEqPreset(String presetKey) async {
    final gains = NeonDspPresets.presets[presetKey] ?? NeonDspPresets.presets['flat']!;
    _activeEqPreset = presetKey;
    _virtual10BandGains = List<double>.from(gains);
    await _applyDspEngineSettings();
  }

  Future<void> setCustomEqBand(int bandIndex, double gainDb) async {
    if (bandIndex < 0 || bandIndex >= _virtual10BandGains.length) return;
    _virtual10BandGains[bandIndex] = gainDb.clamp(-12.0, 12.0);
    _activeEqPreset = 'custom';
    await _applyDspEngineSettings();
  }

  Future<void> resetAllDsp() async {
    _slowedReverbEnabled = false;
    _slowFactor = 0.85;
    _nightcoreEnabled = false;
    _vocalIsolatorEnabled = false;
    _activeEqPreset = 'flat';
    _virtual10BandGains = List<double>.filled(10, 0.0);
    await _applyDspEngineSettings();
  }

  /// Synchronize speed, pitch, loudness enhancer, and hardware equalizer bands on ExoPlayer
  Future<void> _applyDspEngineSettings() async {
    try {
      // 1. Speed & Pitch Manipulation (Native ExoPlayer Sonic AudioProcessor)
      if (_nightcoreEnabled) {
        await _player.setSpeed(1.25);
        await _player.setPitch(1.25);
      } else if (_slowedReverbEnabled) {
        await _player.setSpeed(_slowFactor);
        await _player.setPitch(_slowFactor);
      } else {
        await _player.setSpeed(1.0);
        await _player.setPitch(1.0);
      }

      if (kIsWeb || !Platform.isAndroid) return;

      // 2. Loudness compensation for Slowed+Reverb / CyberBass
      double targetLoudnessGain = 0.0;
      if (_slowedReverbEnabled) targetLoudnessGain += 1.5;
      if (_activeEqPreset == 'cyberbass') targetLoudnessGain += 2.0;
      await _loudnessEnhancer.setTargetGain(targetLoudnessGain);

      // 3. Map 10-band virtual EQ curve (+ optional Vocal Isolator notch & Slowed room warmth)
      // onto Android hardware Equalizer bands via log-frequency interpolation.
      final params = await _androidEqualizer.parameters;
      final minDb = params.minDecibels;
      final maxDb = params.maxDecibels;

      for (final band in params.bands) {
        final double centerHz = band.centerFrequency;
        double interpolatedDb = _interpolateGainForFrequency(centerHz);

        // Slowed + Reverb warm low-shelf & high-air rolloff simulation
        if (_slowedReverbEnabled) {
          if (centerHz <= 160) interpolatedDb += 3.2;
          if (centerHz >= 6000) interpolatedDb -= 2.0;
        }

        // Vocal Isolator / Karaoke mid-band attenuation (300Hz - 3400Hz)
        if (_vocalIsolatorEnabled && centerHz >= 300 && centerHz <= 3400) {
          interpolatedDb -= 10.0;
        }

        await band.setGain(interpolatedDb.clamp(minDb, maxDb));
      }
    } catch (_) {
      // Ignore if hardware equalizer is not yet initialized on a cold stream
    }
  }

  double _interpolateGainForFrequency(double hz) {
    final freqs = NeonDspPresets.frequencies;
    if (hz <= freqs.first) return _virtual10BandGains.first;
    if (hz >= freqs.last) return _virtual10BandGains.last;

    for (int i = 0; i < freqs.length - 1; i++) {
      final f1 = freqs[i];
      final f2 = freqs[i + 1];
      if (hz >= f1 && hz <= f2) {
        final ratio = (hz - f1) / (f2 - f1);
        return _virtual10BandGains[i] +
            ratio * (_virtual10BandGains[i + 1] - _virtual10BandGains[i]);
      }
    }
    return 0.0;
  }

  // =========================================================================
  // STANDARD AUDIO_SERVICE OVERRIDES (LOCK-SCREEN & BLUETOOTH CONTROLS)
  // =========================================================================
  @override
  Future<void> play() => _player.play();

  @override
  Future<void> pause() => _player.pause();

  @override
  Future<void> seek(Duration position) => _player.seek(position);

  @override
  Future<void> skipToNext() async {
    if (_player.hasNext) {
      await _player.seekToNext();
    } else if (_catalogQueue.isNotEmpty) {
      await _player.seek(Duration.zero, index: 0);
    }
    await _player.play();
  }

  @override
  Future<void> skipToPrevious() async {
    if ((_player.position.inSeconds) > 3) {
      await _player.seek(Duration.zero);
      return;
    }
    if (_player.hasPrevious) {
      await _player.seekToPrevious();
    } else if (_catalogQueue.isNotEmpty) {
      await _player.seek(Duration.zero, index: _catalogQueue.length - 1);
    }
    await _player.play();
  }

  @override
  Future<void> skipToQueueItem(int index) async {
    if (index < 0 || index >= _catalogQueue.length) return;
    await _player.seek(Duration.zero, index: index);
  }

  @override
  Future<void> stop() async {
    await _player.stop();
    return super.stop();
  }

  PlaybackState _transformEvent(PlaybackEvent event) {
    return PlaybackState(
      controls: <MediaControl>[
        MediaControl.skipToPrevious,
        if (_player.playing) MediaControl.pause else MediaControl.play,
        MediaControl.stop,
        MediaControl.skipToNext,
      ],
      systemActions: const <MediaAction>{
        MediaAction.seek,
        MediaAction.seekForward,
        MediaAction.seekBackward,
      },
      androidCompactActionIndices: const <int>[0, 1, 3],
      processingState: const <ProcessingState, AudioProcessingState>{
        ProcessingState.idle: AudioProcessingState.idle,
        ProcessingState.loading: AudioProcessingState.loading,
        ProcessingState.buffering: AudioProcessingState.buffering,
        ProcessingState.ready: AudioProcessingState.ready,
        ProcessingState.completed: AudioProcessingState.completed,
      }[_player.processingState]!,
      playing: _player.playing,
      updatePosition: _player.position,
      bufferedPosition: _player.bufferedPosition,
      speed: _player.speed,
      queueIndex: event.currentIndex,
    );
  }
}

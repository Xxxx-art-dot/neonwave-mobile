import 'dart:async';
import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:just_audio/just_audio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'audio_handler.dart';

/// Parsed time-synced LRC lyric line
class LyricLine {
  final double timeSeconds;
  final String text;

  const LyricLine({required this.timeSeconds, required this.text});

  factory LyricLine.fromJson(Map<String, dynamic> json) {
    return LyricLine(
      timeSeconds: (json['time'] is num)
          ? (json['time'] as num).toDouble()
          : double.tryParse(json['time']?.toString() ?? '0') ?? 0.0,
      text: (json['text'] as String?)?.trim().isNotEmpty == true
          ? (json['text'] as String).trim()
          : '♪',
    );
  }
}

/// Central ChangeNotifier managing NEONWAVE catalog, search, DSP state, lyrics, and downloads
class AudioState extends ChangeNotifier {
  final NeonwaveAudioHandler audioHandler;
  final Dio _dio = Dio(
    BaseOptions(
      baseUrl: kBaseServerUrl,
      connectTimeout: const Duration(seconds: 12),
      receiveTimeout: const Duration(seconds: 25),
    ),
  );

  List<TrackModel> _allTracks = <TrackModel>[];
  List<TrackModel> _filteredTracks = <TrackModel>[];
  Set<int> _favoriteIds = <int>{};

  TrackModel? _currentTrack;
  bool _isPlaying = false;
  bool _isLoadingCatalog = false;
  String? _catalogError;
  String _searchQuery = '';
  bool _favoritesOnly = false;

  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;
  bool _shuffleEnabled = false;
  LoopMode _loopMode = LoopMode.off;

  // Synced Lyrics State
  List<LyricLine> _lyrics = <LyricLine>[];
  int _activeLyricIndex = -1;
  bool _isLoadingLyrics = false;
  String _lyricsSource = 'LRCLIB';

  // Smart Sleep Timer
  Timer? _sleepTimer;
  int _sleepRemainingSeconds = 0;

  AudioState({required this.audioHandler}) {
    _bindStreams();
    _loadFavorites();
    fetchTracks();
  }

  // Getters
  List<TrackModel> get tracks => _filteredTracks;
  List<TrackModel> get allTracks => _allTracks;
  TrackModel? get currentTrack => _currentTrack;
  bool get isPlaying => _isPlaying;
  bool get isLoadingCatalog => _isLoadingCatalog;
  String? get catalogError => _catalogError;
  String get searchQuery => _searchQuery;
  bool get favoritesOnly => _favoritesOnly;
  Duration get position => _position;
  Duration get duration => _duration;
  bool get shuffleEnabled => _shuffleEnabled;
  LoopMode get loopMode => _loopMode;

  // DSP Getters delegated from hardware handler
  bool get slowedReverb => audioHandler.slowedReverbEnabled;
  double get slowFactor => audioHandler.slowFactor;
  bool get nightcore => audioHandler.nightcoreEnabled;
  bool get vocalIsolator => audioHandler.vocalIsolatorEnabled;
  String get activeEqPreset => audioHandler.activeEqPreset;
  List<double> get eqGains => audioHandler.virtual10BandGains;

  // Lyrics & Sleep Timer Getters
  List<LyricLine> get lyrics => _lyrics;
  int get activeLyricIndex => _activeLyricIndex;
  bool get isLoadingLyrics => _isLoadingLyrics;
  String get lyricsSource => _lyricsSource;
  int get sleepRemainingSeconds => _sleepRemainingSeconds;

  void _bindStreams() {
    audioHandler.player.playingStream.listen((bool playing) {
      _isPlaying = playing;
      notifyListeners();
    });

    audioHandler.player.positionStream.listen((Duration pos) {
      _position = pos;
      _updateActiveLyricLine(pos.inMilliseconds / 1000.0);
      notifyListeners();
    });

    audioHandler.player.durationStream.listen((Duration? dur) {
      if (dur != null && dur.inSeconds > 0) {
        _duration = dur;
        notifyListeners();
      }
    });

    audioHandler.mediaItem.listen((item) {
      if (item == null) return;
      final id = int.tryParse(item.id);
      if (id != null) {
        final match = _allTracks.where((t) => t.id == id).toList();
        if (match.isNotEmpty && _currentTrack?.id != match.first.id) {
          _currentTrack = match.first;
          _duration = Duration(seconds: _currentTrack!.duration);
          fetchLyricsForTrack(_currentTrack!);
          notifyListeners();
        }
      }
    });
  }

  // =========================================================================
  // 1. CATALOG FETCHING & REAL-TIME SEARCH (`/api/tracks?limit=150`)
  // =========================================================================
  Future<void> fetchTracks({String query = ''}) async {
    _isLoadingCatalog = true;
    _catalogError = null;
    notifyListeners();

    try {
      final uri = Uri.parse('$kBaseServerUrl/api/tracks').replace(
        queryParameters: <String, String>{
          'limit': '150',
          'sort': 'added_at',
          'order': 'desc',
          if (query.trim().isNotEmpty) 'q': query.trim(),
        },
      );

      final response = await http.get(uri).timeout(const Duration(seconds: 12));
      if (response.statusCode != 200) {
        throw Exception('HTTP ${response.statusCode} from $kBaseServerUrl');
      }

      final Map<String, dynamic> decoded =
          jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
      final List<dynamic> rawList =
          (decoded['items'] ?? decoded['tracks'] ?? <dynamic>[]) as List<dynamic>;

      _allTracks = rawList
          .map((item) => TrackModel.fromJson(item as Map<String, dynamic>))
          .toList();

      _applyLocalFilter();
      if (_currentTrack == null && _allTracks.isNotEmpty) {
        _currentTrack = _allTracks.first;
        _duration = Duration(seconds: _currentTrack!.duration);
        await audioHandler.loadPlaylist(_allTracks, initialIndex: 0, autoPlay: false);
      }
    } catch (e) {
      _catalogError = 'Unable to reach $kBaseServerUrl/api/tracks ($e)';
    } finally {
      _isLoadingCatalog = false;
      notifyListeners();
    }
  }

  void setSearchQuery(String query) {
    _searchQuery = query;
    _applyLocalFilter();
    notifyListeners();
  }

  void toggleFavoritesFilter() {
    _favoritesOnly = !_favoritesOnly;
    _applyLocalFilter();
    notifyListeners();
  }

  void _applyLocalFilter() {
    final q = _searchQuery.trim().toLowerCase();
    _filteredTracks = _allTracks.where((track) {
      if (_favoritesOnly && !_favoriteIds.contains(track.id)) {
        return false;
      }
      if (q.isEmpty) return true;
      return track.title.toLowerCase().contains(q) ||
          track.artist.toLowerCase().contains(q);
    }).toList();
  }

  // =========================================================================
  // 2. PLAYBACK & TRANSPORT CONTROLS
  // =========================================================================
  Future<void> playTrack(TrackModel track) async {
    _currentTrack = track;
    _duration = Duration(seconds: track.duration);
    notifyListeners();
    await audioHandler.playTrack(track, fullCatalog: _filteredTracks.isNotEmpty ? _filteredTracks : _allTracks);
    fetchLyricsForTrack(track);
  }

  Future<void> togglePlayPause() async {
    if (_currentTrack == null && _allTracks.isNotEmpty) {
      await playTrack(_allTracks.first);
      return;
    }
    if (_isPlaying) {
      await audioHandler.pause();
    } else {
      await audioHandler.play();
    }
  }

  Future<void> seek(Duration position) => audioHandler.seek(position);
  Future<void> playNext() => audioHandler.skipToNext();
  Future<void> playPrevious() => audioHandler.skipToPrevious();

  Future<void> toggleShuffle() async {
    _shuffleEnabled = !_shuffleEnabled;
    await audioHandler.player.setShuffleModeEnabled(_shuffleEnabled);
    notifyListeners();
  }

  Future<void> cycleLoopMode() async {
    if (_loopMode == LoopMode.off) {
      _loopMode = LoopMode.all;
    } else if (_loopMode == LoopMode.all) {
      _loopMode = LoopMode.one;
    } else {
      _loopMode = LoopMode.off;
    }
    await audioHandler.player.setLoopMode(_loopMode);
    notifyListeners();
  }

  // =========================================================================
  // 3. NATIVE DSP CONTROLS (SLOWED+REVERB, NIGHTCORE, VOCAL ISOLATOR, 10-BAND EQ)
  // =========================================================================
  Future<void> toggleSlowedReverb() async {
    await audioHandler.setSlowedReverb(!slowedReverb);
    notifyListeners();
  }

  Future<void> updateSlowFactor(double factor) async {
    await audioHandler.setSlowedReverb(slowedReverb, customFactor: factor);
    notifyListeners();
  }

  Future<void> toggleNightcore() async {
    await audioHandler.setNightcore(!nightcore);
    notifyListeners();
  }

  Future<void> toggleVocalIsolator() async {
    await audioHandler.setVocalIsolator(!vocalIsolator);
    notifyListeners();
  }

  Future<void> selectEqPreset(String presetKey) async {
    await audioHandler.applyEqPreset(presetKey);
    notifyListeners();
  }

  Future<void> setEqBandGain(int index, double gainDb) async {
    await audioHandler.setCustomEqBand(index, gainDb);
    notifyListeners();
  }

  Future<void> resetAllDsp() async {
    await audioHandler.resetAllDsp();
    notifyListeners();
  }

  // =========================================================================
  // 4. SYNCED LYRICS (`/api/track/{id}/lyrics` + LRCLIB FALLBACK)
  // =========================================================================
  Future<void> fetchLyricsForTrack(TrackModel track) async {
    _isLoadingLyrics = true;
    _activeLyricIndex = -1;
    notifyListeners();

    try {
      final resp = await _dio.get<Map<String, dynamic>>('/api/track/${track.id}/lyrics');
      final data = resp.data ?? <String, dynamic>{};
      final rawLines = (data['lines'] as List<dynamic>?) ?? <dynamic>[];

      if (rawLines.isNotEmpty) {
        _lyrics = rawLines
            .map((e) => LyricLine.fromJson(e as Map<String, dynamic>))
            .toList();
        _lyricsSource = (data['synced'] == true) ? 'LRCLIB SYNCED' : 'LRCLIB PLAIN';
      } else {
        _lyrics = _buildFallbackLyrics(track);
        _lyricsSource = 'SYNTH TIMECODE';
      }
    } catch (_) {
      _lyrics = _buildFallbackLyrics(track);
      _lyricsSource = 'SYNTH TIMECODE';
    } finally {
      _isLoadingLyrics = false;
      notifyListeners();
    }
  }

  List<LyricLine> _buildFallbackLyrics(TrackModel track) {
    final total = track.duration > 0 ? track.duration.toDouble() : 180.0;
    final lines = <String>[
      '♪ [NEONWAVE STREAM // ${track.title.toUpperCase()}] ♪',
      'Artist: ${track.artist}',
      'Streaming via HTTP 206 Byte-Range Engine',
      'Hardware ExoPlayer DSP Active on Android',
      'No time-synced LRC found on LRCLIB for this track',
      'Tap any line to seek directly in the audio stream',
    ];
    final step = total / lines.length;
    return List<LyricLine>.generate(
      lines.length,
      (i) => LyricLine(timeSeconds: i * step, text: lines[i]),
    );
  }

  void _updateActiveLyricLine(double currentSeconds) {
    if (_lyrics.isEmpty) return;
    int idx = 0;
    for (int i = 0; i < _lyrics.length; i++) {
      if (currentSeconds >= _lyrics[i].timeSeconds) {
        idx = i;
      } else {
        break;
      }
    }
    if (idx != _activeLyricIndex) {
      _activeLyricIndex = idx;
    }
  }

  // =========================================================================
  // 5. DIRECT WEB INGESTION (`POST /api/download`)
  // =========================================================================
  Future<String> ingestWebUrl({
    required String url,
    String? customTitle,
    String? customArtist,
  }) async {
    final response = await _dio.post<Map<String, dynamic>>(
      '/api/download',
      data: <String, dynamic>{
        'url': url.trim(),
        if (customTitle != null && customTitle.trim().isNotEmpty)
          'title': customTitle.trim(),
        if (customArtist != null && customArtist.trim().isNotEmpty)
          'artist': customArtist.trim(),
      },
    );
    final msg = response.data?['message']?.toString() ??
        'Background 320kbps MP3 download queued!';
    // Poll catalog refresh after a short delay
    Future<void>.delayed(const Duration(seconds: 6), () => fetchTracks(query: _searchQuery));
    return msg;
  }

  // =========================================================================
  // 6. FAVORITES & SMART SLEEP TIMER
  // =========================================================================
  bool isFavorite(int trackId) => _favoriteIds.contains(trackId);

  Future<void> toggleFavorite(int trackId) async {
    if (_favoriteIds.contains(trackId)) {
      _favoriteIds.remove(trackId);
    } else {
      _favoriteIds.add(trackId);
    }
    _applyLocalFilter();
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList(
        'neonwave_favorites',
        _favoriteIds.map((e) => e.toString()).toList(),
      );
    } catch (_) {}
  }

  Future<void> _loadFavorites() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final list = prefs.getStringList('neonwave_favorites') ?? <String>[];
      _favoriteIds = list.map((s) => int.tryParse(s) ?? -1).where((i) => i >= 0).toSet();
      notifyListeners();
    } catch (_) {}
  }

  void setSleepTimer(int minutes) {
    _sleepTimer?.cancel();
    if (minutes <= 0) {
      _sleepRemainingSeconds = 0;
      notifyListeners();
      return;
    }
    _sleepRemainingSeconds = minutes * 60;
    notifyListeners();
    _sleepTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      _sleepRemainingSeconds -= 1;
      if (_sleepRemainingSeconds <= 0) {
        timer.cancel();
        _sleepRemainingSeconds = 0;
        audioHandler.pause();
      }
      notifyListeners();
    });
  }
}
